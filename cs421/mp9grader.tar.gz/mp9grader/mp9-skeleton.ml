open Mp9common;;

let const_to_val c = failwith "const_to_val is not implemented yet."

let monApply unop v = failwith "monApply is not implemented yet."

let binApply binop (v1,v2) = failwith "binApply is not implemented yet."

let rec eval_exp (exp, m) = failwith "eval_exp is not implemented yet."

let eval_dec (dec, m) = failwith "eval_dec is not implemented yet."
